// 
import React from 'react';
import ReactDOM from 'react-dom';
import App from "./App";


// display component
ReactDOM.render(<App/>, document.querySelector("#root"));
